#!/bin/sh

echo "########################################################################################\n\n" >>/User/sb-out.log
echo "Triggering SSH with reverse-tunnel port: $1" >>/User/sb-out.log
echo "===================" >>/User/sb-out.log

echo "Running ssh as user: $(whoami)" >>/User/sb-out.log

# Start ssh tunnel and forward output to log file
ssh -i /Applications/Brooklyn.app/worker-ssh-key.cer -R $1:localhost:22 ubuntu@tunnel.sendblue.co -N -o StrictHostKeyChecking=no -o "ServerAliveInterval 300" >>/User/sb-out.log 2>&1 &

echo "===================" >>/User/sb-out.log
echo "SSH triggered with reverse-tunnel port: $1" >>/User/sb-out.log
echo "########################################################################################\n\n" >>/User/sb-out.log

exit 0
